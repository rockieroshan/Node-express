import { CommonModule } from '@angular/common';
import { NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { DialogModule } from 'primeng/dialog';
import { LoaderComponent } from './loader/loader.component';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { InputTextModule } from 'primeng/inputtext';
import { TooltipModule } from 'primeng/tooltip';
import { NotificationComponent } from './notification/notification.component';

import { OverlayPanelModule } from 'primeng/overlaypanel';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AngularFontAwesomeModule,
    OverlayPanelModule,
    DialogModule,
    ToastModule,
    InputTextModule,
    TooltipModule
  ],
  declarations: [
    LoaderComponent,
    NotificationComponent
  ],
  entryComponents: [],
  exports: [
    LoaderComponent,
    NotificationComponent
  ],
  providers: [
    MessageService
  ]
})
export class SharedComponentsModule {
  constructor() {}
  ngDoBootstrap() {}
}
