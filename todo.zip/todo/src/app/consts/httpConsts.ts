export const MANAGE    = 'MANAGE';

