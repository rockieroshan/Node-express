import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { TooltipModule } from 'primeng/tooltip';
// import { CalendarModule } from 'primeng/primeng';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {TableModule} from 'primeng/table';

import { LandingRoutingModule } from './landing-routing.module';
import { LandingComponent } from './landing.component';
import { SharedComponentsModule } from '../shared/sharedComponent.module';

@NgModule({
  declarations: [LandingComponent],
  imports: [
    CommonModule,
    TableModule,
    LandingRoutingModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    DialogModule,
    // CalendarModule,
    FormsModule,
    NgbModule,
    // TooltipModule,
    MultiSelectModule,
    SharedComponentsModule
  ]
})
export class LandingModule {}
