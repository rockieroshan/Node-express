import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

import { MANAGE } from '../consts/httpConsts';

@Injectable({
  providedIn: 'root'
})
export class LandingService {
  constructor(private http: HttpClient) {}

  getList(): Observable<any> {
    // const token = this.auth.getToken();
    return this.http.get(`https://api.myjson.com/bins/8k7k4`, {
      headers: {
        'X-META': MANAGE,
        // token
      }
    });
  }

 
  // getGroupDetails(id: string): Observable<any> {
  //   // const token = this.auth.getToken();
  //   return this.http.get(`V1/distribution-list/${id}`, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }

  // updategroupDetails(data: any, id: string, members): Observable<any> {
  //   // const token = this.auth.getToken();
  //   let keyword = '';
  //   if (members) {
  //     keyword = '/members';
  //   }
  //   return this.http.post(`V1/distribution-list/${id}${keyword}`, data, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }

  // deletemember(group_id, payload): Observable<any> {
  //   // const token = this.auth.getToken();
  //   return this.http.post(`V1/distribution-list/${group_id}/members`, payload, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }
  // deleteGroup(user_id): Observable<any> {
  //   // const token = this.auth.getToken();
  //   return this.http.delete(`V1/distribution-list/${user_id}`, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }
  // createGroupSer(payload): Observable<any> {
  //   // const token = this.auth.getToken();
  //   return this.http.post(`V1/distribution-list/add`, payload, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }
  // getUserList(): Observable<any> {
  //   // const token = this.auth.getToken();
  //   return this.http.get(`V1/user`, {
  //     headers: {
  //       'X-META': MANAGE,
  //       // token
  //     }
  //   });
  // }
}
