import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormArray, AbstractControl, FormControl, PatternValidator } from '@angular/forms';
import { LandingService } from './landing.service';
import { NotificationService } from '../shared/notification/notification.service';
import { ConfirmDialogModule, ConfirmationService } from 'primeng';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.sass']
})
export class LandingComponent implements OnInit {
  submitted = false;
  loading = false;
  cols: {}[];
  name: string;
  username: string;
  email: string;
  phone: string;
  registerForm: any;
  results: any;
  display: boolean;
  headerName: string;
  confirmCompanyHeader: string;
  confirmTxt: string;
  groupName: string;
  flag: boolean;
  enableName: boolean;
  enableUser: boolean;
  enableEmail: boolean;
  enablePhone: boolean;
  constructor(
    private landingService: LandingService,
    private route: ActivatedRoute,
    private router: Router,
    public msg: NotificationService,
    private formBuilder: FormBuilder,
    public confirm: ConfirmationService
  ) { }

  ngOnInit() {
    this.flag = true;
    this.enableName = false;
    this.enableUser = false;
    this.enableEmail = false;
    this.enablePhone = false;
    this.getList();
    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'username', header: 'User Name' },
      { field: 'email', header: 'Email' },
      { field: 'phone', header: 'Phone' }
    ];
    this.loading = true;
  }

  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return false;
    }
  }
  getList() {
    this.loading = true;
    this.landingService.getList().subscribe(res => {
      this.results = res;
      this.loading = false;
    }, err => {
      this.loading = false;
    });
  }
  viewDetails(rowData) {
    this.display = true;
    this.flag = false;
    this.name = rowData.name;
    this.username = rowData.username;
    this.email = rowData.email;
    this.phone = rowData.phone;
    this.headerName = 'Edit Group';
  }
  showDialog() {
    this.display = true;
    this.name = '';
    this.username = '';
    this.email = '';
    this.phone = '';
    this.flag = true;
    this.headerName = 'Create New Group';
  }
  cancel() {
    if (this.groupName !== '') {
      this.confirmCompanyHeader = 'Cancel?';
      this.confirmTxt = 'Yes';
      this.confirm.confirm({
        message: 'Are you sure you want to discard this Group?',
        accept: () => {
          this.display = false;
        },
        reject: () => {
        }
      });
    } else {
      this.display = false;
    }
  }
  focus(field: string) {
    if  (field === 'name') {
      this.enableName = true;
    }
    if  (field === 'username') {
      this.enableUser = true;
    }
    if  (field === 'email') {
      this.enableEmail = true;
    }
    if  (field === 'phone') {
      this.enablePhone = true;
    }
  }
}
