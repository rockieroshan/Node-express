import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BackendInterceptor } from './interceptors/backend.interceptors';
import { ConfirmationService } from 'primeng/api';
import { FullCalendarModule } from 'primeng/fullcalendar';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule
} from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// Primeng components
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { OverlayPanelModule } from 'primeng/overlaypanel';

// shared components module
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { NotificationService } from './shared/notification/notification.service';
import { SharedComponentsModule } from './shared/sharedComponent.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    FullCalendarModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    HttpClientModule,
    SharedComponentsModule,
    NgbModule,
    DialogModule,
    DropdownModule,
    OverlayPanelModule

  ],
  providers: [
    BsModalRef,
    NotificationService,
    ConfirmationService,
    { provide: HTTP_INTERCEPTORS, useClass: BackendInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
