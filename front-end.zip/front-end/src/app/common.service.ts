import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CommonService {

  successMessage = new Subject();

  constructor() { }



  getHeaders() {
    const httpHeaders = new HttpHeaders ({
      'Content-Type': 'application/json'
    });
    return httpHeaders;
}
}
