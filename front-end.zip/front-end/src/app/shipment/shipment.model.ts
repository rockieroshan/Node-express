export class ShipmentModel {
    constructor(
      public shipmentType: string = '',
      public weightDesc: string = '',
      public id: string = '',
      public shipmentStatus: string = '',
      public weightID: string = '',
      public typeID: string = '',
      public origin: string = '',
      public destination: string = '',
      public delivered: string = '',
      public officeName: string = '',
      public OfficeId: string = '',
      public OfficeCode: string = '',
      public officeVal: string = '',
   
    ) { 
      
    }
  
  }