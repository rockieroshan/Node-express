import { Component, OnInit, ViewChild } from "@angular/core";
import { PostOfficeService } from "../post-office.service";
import { ShipmentModel } from "./shipment.model";
import { NgForm } from "@angular/forms";
import { Router } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';

@Component({
  selector: "app-shipment",
  templateUrl: "./shipment.component.html",
  styleUrls: ["./shipment.component.scss"],
  providers: [MessageService]
})
export class ShipmentComponent implements OnInit {
  @ViewChild("shipmentForm") shipmentForm: NgForm;
  shipmentModel: ShipmentModel;
  cols: { field: string; header: string }[];
  arg: any;
  formatedData: any[];
  updateObj: {};
  newShipmentObj:{};
  weightVal: any;
  officeId: any;
  officeresID: any;
  putFlag: boolean;
  status: string;
  row: any;
  temVal: any;
  tempWeight: string;
  changeSelectid: any;
  tempId: any;
  tempName: any;
  rowKey: any;
  constructor(private _PostOfficeService: PostOfficeService, private router: Router,private messageService: MessageService) {}

  ngOnInit() {
    this.putFlag = false;
    this.shipmentModel = new ShipmentModel();
    this.shipmentModel['officeName'] = '';
    this.shipmentModel['weightDesc'] = '';
    this.reset()
    this.cols = [
      { field: "shipmentType", header: "Type Of Shipping" },
      { field: "shipmentStatus", header: "Shipping Status" },
      { field: "weightDesc", header: "Weight" },
      { field: "officeName", header: "Office Name" }
    ];
    this.getshipmentData();
    this.loadOffice();
  }
  loadOffice() {
    this._PostOfficeService.getofficeList().subscribe(data => {
      this.officeresID = data;
    }, error => {
      this.errorHandler(error, 'Error');
    });
  }
  getshipmentData() {
    this._PostOfficeService.getShipmentList().subscribe(
      res => {
        this.arg = res;
        this.formatedData = [];
        this.arg.forEach((data, index) => {
          this.formatedData.push({
            shipmentType: data.type.name,
            weightDesc: data.weight.desc,
            id: data.id,
            shipmentStatus: this.getShipmentStatus(data),
            weightID: data.weight.id,
            typeID: data.type.id,
            origin: data.origin,
            destination: data.destination,
            delivered: data.delivered,
            officeName: data.office.name,
            OfficeId: data.office.id,
            OfficeCode: data.office.PLZ
          });
        });
      },
      error => {
        this.errorHandler(error, "Error");
      }
    );
  }
  errorHandler(error, title) {
    this.showError();
  }
  getShipmentStatus(data) {
    if (data.origin === true) {
      return "At Origin";
    } else if (data.delivered === true) {
      return "Item has been Delivered";
    } else if (data.destination === true) {
      return "Item has reached your destination";
    } else {
      return "Item not found";
    }
  }
  addShipment() {
    if(this.shipmentModel['weightDesc'] === '0'){
      this.temVal = "Less than 1kg"
    }
    if(this.shipmentModel['weightDesc'] === '1'){
      this.temVal = "Between 1kg & 5kg"
    }
    if(this.shipmentModel['weightDesc'] === '2'){
      this.temVal = "More than 5kg"
    }
    if(this.putFlag === true){
      this.updateObj = {
        "id": this.row.id,
        "type": {
            "id": +this.shipmentModel['shipmentType'],
            "name": this.shipmentModel['shipmentType'] === '1' ? 'package': 'letter'
        },
        "origin": this.shipmentModel['shipmentStatus'] === 'origin' ? true : false,
        "destination": this.shipmentModel['shipmentStatus'] === 'destination' ? true : false,
        "delivered": this.shipmentModel['shipmentStatus'] === 'delivered' ? true : false,
        "weight": {
            "id": +this.shipmentModel['weightDesc'],
            "desc": this.temVal
        },
        "office": {
            "id": this.changeSelectid ? this.changeSelectid: this.shipmentModel['officeName'],
            "PLZ": this.tempId,
            "name": this.tempName
        }
    }
      this._PostOfficeService.updateShipmentList(this.updateObj).subscribe(res => {
        this.getshipmentData();
        this.reset();
        this.showSuccess("Record Updated.")
      }, error => {
        this.errorHandler(error, 'Error');
      });
      this.reset();
      
    }if(this.putFlag === false){
      this.newShipmentObj = {
        'type': +this.shipmentModel['shipmentType'],
        'origin': this.shipmentModel['shipmentStatus'] === 'origin' ? true : false,
        'destination': this.shipmentModel['shipmentStatus'] === 'destination' ? true : false,
        'delivered': this.shipmentModel['shipmentStatus'] === 'delivered' ? true : false,
        'weight': +this.shipmentModel['weightDesc'],
        'office': this.shipmentModel['officeName']
      };
      this._PostOfficeService.addShipmentList(this.newShipmentObj).subscribe(
        res => {
          this.reset();
          this.showSuccess("New Record Added")
        },
        error => {
          this.errorHandler(error, "Error");
        }
        
      );
      this.getshipmentData();
    }
  }
  editList(rowData) {
    if (rowData.shipmentStatus === 'At Origin') {
      this.status = 'origin'
    }
    if (rowData.shipmentStatus === 'Item has been Delivered') {
      this.status = 'delivered'
    }
    if (rowData.shipmentStatus === 'Item has reached your destination') {
      this.status = 'destination'
    }
    if(rowData['weightDesc'] === "Less than 1kg"){
      this.tempWeight = "0"
    }
    if(rowData['weightDesc'] === "Between 1kg & 5kg"){
      this.tempWeight = "1"
    }
    if(rowData['weightDesc'] === "More than 5kg"){
      this.tempWeight = "2"
    }
    this.putFlag = true;
    this.shipmentModel['shipmentType'] = rowData.shipmentType === 'package' ? '1' : '0'
    this.shipmentModel['shipmentStatus'] = this.status;
    this.shipmentModel['weightDesc'] = this.tempWeight;
    this.shipmentModel['officeName'] = rowData.OfficeId;
    this.row = rowData;
  }
  changeSelectName(e){
    this.changeSelectid = e.target.value;
  this.officeresID.forEach(e => {
    if(e.id === this.changeSelectid){
      this.tempId = e.PLZ;
      this.tempName = e.name;
      console.log(this.tempId,this.tempName, 't')
    }
  })
    console.log(this.changeSelectid, 'e')
  }
  deleteList(rowData) {
    this._PostOfficeService.deleteShipmentList(rowData.id).subscribe(res => {
      this.formatedData.splice(rowData.id, 1);
      this.getshipmentData();
      this.showSuccess("Record Deleted");
    }, error => {
      this.errorHandler(error, 'Error');
    });
    
    this.messageService.clear('c');
 
  }
  showConfirm(rowData){
    this.messageService.clear();
    this.messageService.add({key: 'c', sticky: true, severity:'warn', summary:'Are you sure?', detail:'Confirm to proceed'});
    this.rowKey = rowData;
  }
  onConfirm(){
    this.deleteList(this.rowKey);
  }
  showError() {
    this.messageService.add({severity:'error', summary: 'Error Message', detail:'Validation failed'});
  }
  showSuccess(str) {
    this.messageService.add({severity:'success', summary: 'Success Message', detail:str});
  }
  onReject() {
    this.messageService.clear('c');
  }
  clear() {
    this.messageService.clear();
  }
  back(){
    this.router.navigateByUrl('/');
  }
  reset(){
    this.shipmentModel['shipmentType'] = '';
    this.shipmentModel.shipmentStatus = '';
    this.shipmentModel.weightDesc = '';
    this.shipmentModel.officeName = '';
  }
}

