export class OfficeModel {
    constructor(
      public plz: string = '',
      public name: string = '',
      public rowid: string = ''
    ) { 
      
    }
  
  }