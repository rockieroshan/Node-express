import { Component, OnInit, ViewChild } from '@angular/core';
import { OfficeModel } from './office.model';
import { PostOfficeService } from '../post-office.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-office',
  templateUrl: './office.component.html',
  styleUrls: ['./office.component.scss'],
  providers: [MessageService]
})
export class OfficeComponent implements OnInit {
  @ViewChild('officeForm') officeForm: NgForm;
  officeModel:OfficeModel
  arg: any = [];
  searchResults: any;
  cols: { field: string; header: string; }[];
  putFlag: boolean;
  newOfficetObj: {};
  selectedRow: boolean;
  rowKey: any;
  updateOfficetObj: { "PLZ": string; "name": string; "id": string; };
  selectedRowid: any;

  constructor(private _PostOfficeService: PostOfficeService, private router: Router, private messageService: MessageService) { }

  ngOnInit() {
    this.putFlag = false;
    this.officeModel =  new OfficeModel();
    this.loadOffice();
    this.cols = [
      { field: 'PLZ', header: 'ZIP Code' },
      { field: 'name', header: 'Place Name' }
    ];
  }
  loadOffice() {
    this._PostOfficeService.getofficeList().subscribe(data => {
      this.arg = data;
      if (this.arg && this.arg.length > 0) {
        this.searchResults = this.arg && this.arg.map((data, index) => {
          return {
            index: index + 1,
            ...data
          };
        });
      }
    }, error => {
      this.errorHandler(error, 'Error');
    });
  }
 
  errorHandler(error, title) {
    this.showError()
  }
  addOfficelist() {
    if (this.putFlag === false) {
      this.newOfficetObj = {
        "PLZ": this.officeModel['plz'],
        "name": this.officeModel['name']
      }
      this._PostOfficeService.addofficeList(this.newOfficetObj).subscribe(res => {
        this.reset();
        this.showSuccess("New Record Added");
        this.loadOffice();
        this.reset();
      }, error => {
        this.errorHandler(error, 'Error');
      });
      this.putFlag = true;
    } else {
      this.updateOfficetObj = {
        "PLZ": this.officeModel['plz'],
        "name": this.officeModel['name'],
        "id": this.selectedRowid,
      }

      this._PostOfficeService.updateofficeList(this.updateOfficetObj).subscribe(res => {
        this.reset();
        this.loadOffice();
        this.showSuccess("Record Updated")
      }, error => {
        this.errorHandler(error, 'Error');
      });
      
    }
    this.reset();
  }
  editList(rowData) {
    console.log(rowData)
    this.selectedRow = rowData
    this.putFlag = true;
    this.officeModel['plz'] = rowData.PLZ;
    this.officeModel['name'] = rowData.name;
    this.selectedRowid = rowData.id
  }
  showConfirm(rowData){
      this.messageService.clear();
      this.messageService.add({key: 'c', sticky: true, severity:'warn', summary:'Are you sure?', detail:'Confirm to proceed'});
      this.rowKey = rowData;
    }
  onConfirm(){
    this.deleteList(this.rowKey);
  }
  showError() {
    this.messageService.add({severity:'error', summary: 'Error Message', detail:'Validation failed'});
}
  deleteList(rowData) {
      this._PostOfficeService.deleteofficeList(rowData.id).subscribe(res => {
        this.searchResults.splice(rowData.id, 1);
        this.loadOffice();
        this.showSuccess("Record Deleted")
      }, error => {
        this.errorHandler(error, 'Error');
      });
      console.log('yess', rowData);
  this.messageService.clear('c');
}

showSuccess(str) {
  this.messageService.add({severity:'success', summary: 'Success Message', detail:str});
}
onReject() {
  this.messageService.clear('c');
}
clear() {
  this.messageService.clear();
}
  back(){
    this.router.navigateByUrl('/');
  }
  reset(){
    this.officeModel.plz = '';
    this.officeModel.name = '';
  }
}
