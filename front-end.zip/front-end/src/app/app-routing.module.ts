import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShipmentComponent } from './shipment/shipment.component';
import { OfficeComponent } from './office/office.component';

const routes: Routes = [
  { path: 'shipment', component: ShipmentComponent },
  { path: 'office', component: OfficeComponent },
  { path: '', component: HomeComponent },
  { path: '', component: HomeComponent },
  { path: '**', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
