import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { map } from 'rxjs/operators';
import 'rxjs/add/operator/map'
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class PostOfficeService {

  private localUrl = '';
  private url = this.localUrl || environment.baseUrl;
  private listShipment = this.url + '/shipment/list';
  private addShipment = this.url + '/shipment/add';
  private deleteShipment = this.url + '/shipment/delete';
  private updateShipment = this.url + '/shipment/update';
  private getupdate = this.url + '/shipment/get';
  private officeList = this.url + '/office/list';
  private addNewOffice = this.url + '/office/add';
  private officeUpdate = this.url + '/office/update';
  private officeDelete = this.url + '/office/delete';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getShipmentList() {
    return this.http.get(this.listShipment, {
      headers: this.commonService.getHeaders()
    });
  }

  addShipmentList(newShipmentObj) {
    return this.http.post(this.addShipment, newShipmentObj, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }
  updateShipmentList(updatedShipmentObj) {
    return this.http.post(this.updateShipment, updatedShipmentObj, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }
  updateShipmentGet(id) {
    return this.http.post(this.getupdate, {id}, {
      headers: this.commonService.getHeaders()
    });
  }
  deleteShipmentList(id) {
    return this.http.post(this.deleteShipment, {id}, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }

  getofficeList() {
    return this.http.get(this.officeList, {
      headers: this.commonService.getHeaders()
    });
  }
  addofficeList(newofficeObj) {
    return this.http.post(this.addNewOffice, newofficeObj, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }
  updateofficeList(updatedShipmentObj) {
    return this.http.post(this.officeUpdate, updatedShipmentObj, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }
  deleteofficeList(id) {
    return this.http.post(this.officeDelete, {id}, {
      responseType: 'text',
      headers: this.commonService.getHeaders()
    });
  }
  
}
