import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {TableModule} from 'primeng/table';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap';
import {ToastModule} from 'primeng/toast';

import { AppComponent } from './app.component';
import { OfficeComponent } from './office/office.component';
import { ShipmentComponent } from './shipment/shipment.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { MessageService } from 'primeng/components/common/messageservice';



@NgModule({
  declarations: [
    AppComponent,
    OfficeComponent,
    ShipmentComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    ToastModule,
    BrowserAnimationsModule,
    TableModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BsDropdownModule.forRoot()
  ],
  providers: [MessageService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
